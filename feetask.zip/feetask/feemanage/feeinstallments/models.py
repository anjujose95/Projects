from django.db import models


# Create your models here.
installments=(('One Time','One Time'),('Two Times','Two Times'),('Three Times','Three Times'))
class feeinstallment(models.Model):
    Installment_type=models.CharField(max_length=100,choices=installments,default='installment types')
    installment_date=models.DateField()
    installment_amount=models.BigIntegerField()
    Balance_amount=models.BigIntegerField(default=0)
class feeinstallmenttwo(models.Model):
    Installment_type=models.CharField(max_length=100,choices=installments,default='installment types')
    installment_date1=models.DateField()
    installment_amount1=models.BigIntegerField()
    Balance_amount1=models.IntegerField(default=0)
    installment_date2=models.DateField()
    installment_amount2=models.BigIntegerField()
    Balance_amount2=models.BigIntegerField()
class feeinstallmentthree(models.Model):
    Installment_type=models.CharField(max_length=100,choices=installments,default='installment types')
    installment_date11=models.DateField()
    installment_amount11=models.BigIntegerField()
    Balance_amount11=models.BigIntegerField()
    installment_date21=models.DateField()
    installment_amount21=models.BigIntegerField()
    Balance_amount21=models.BigIntegerField()
    installment_date31=models.DateField()
    installment_amount31=models.BigIntegerField()
    Balance_amount31=models.BigIntegerField()



