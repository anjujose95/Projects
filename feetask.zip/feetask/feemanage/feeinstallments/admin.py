from django.contrib import admin
from.models import feeinstallment,feeinstallmenttwo,feeinstallmentthree

# Register your models here.
class feeinstallmentAdmin(admin.ModelAdmin):
  list_display = ("installment_date", "installment_amount", "Balance_amount",)
class feeinstallmenttwoAdmin(admin.ModelAdmin):
  list_display = ("installment_date1","installment_amount1","Balance_amount1","installment_date2","installment_amount2","Balance_amount2",)
class feeinstallmentthreeAdmin(admin.ModelAdmin):
  list_display = ("installment_date11","installment_amount11","Balance_amount11","installment_date21","installment_amount21","Balance_amount21","installment_date31","installment_amount31","Balance_amount31",)
  
admin.site.register(feeinstallment,feeinstallmentAdmin)
admin.site.register(feeinstallmenttwo,feeinstallmenttwoAdmin)
admin.site.register(feeinstallmentthree,feeinstallmentthreeAdmin)

