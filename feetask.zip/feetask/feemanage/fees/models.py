from django.db import models

# Create your models here.
class Batches(models.Model):
    Batch=models.CharField(max_length=50)
    Start_date=models.DateField()
    End_date=models.DateField()
    Active=models.BooleanField()
State=(('Kerala','Kerala'),('Tamilnadu','Tamilnadu'),('Karnataka','Karnataka'),('Rajasthan','Rajasthan'))
district=(('Ernakulam','Ernakulam'),('Kollam','Kollam'),('Alappuzha','Alappuzha'))
class Branches(models.Model):
    Branch=models.CharField(max_length=100)
    Address=models.CharField(max_length=100)
    Street=models.CharField(max_length=100)
    State=models.CharField(max_length=50,choices=State,default='Statename',)
    district =models.CharField(max_length=50,choices=district,default='districtname',)
    pincode=models.PositiveIntegerField()
    Mobile=models.CharField(max_length=100)
    Email=models.EmailField(max_length=100)
    Active=models.BooleanField()
courses=(('BCA','BCA'),('MCA','MCA'),('Btech','Btech'),('Mtech','Mtech'),('Others','Others'))
feestype=(('Gpay','Gpay'),('Credit card','Credit card'),('Cash','Cash'),('Other','Other'))
class Coursefees(models.Model):
    Course=models.CharField(max_length=50,choices=courses,default='coursename',)
    Feetype=models.CharField(max_length=50,choices=feestype,default='feetypes',)
    Amount=models.IntegerField()
    Tax=models.CharField(max_length=50)
    Installment_period=models.IntegerField()
class Course(models.Model):
    course=models.CharField(max_length=100)
    Active=models.BooleanField()
class District(models.Model):
    State=models.CharField(max_length=100)
    District_name=models.CharField(max_length=50)
    Active=models.BooleanField()
class State(models.Model):
    State_name=models.CharField(max_length=50)
    Active=models.BooleanField()

    