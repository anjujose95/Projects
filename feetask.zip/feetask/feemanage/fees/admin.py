from django.contrib import admin
from.models import Batches,Branches,Coursefees,Course,District,State

# Register your models here.
admin.site.register(Batches)
admin.site.register(Branches)
admin.site.register(Coursefees)
admin.site.register(Course)
admin.site.register(District)
admin.site.register(State)

