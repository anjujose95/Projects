from django.contrib import admin
from.models import Employee

# # Register your models here.
# admin.site.register(Position)
admin.site.register(Employee)
